[
  ["/usr/lib/ladspa/sine.so", 1, 1045, "sine_faac"]
]
